
<?php 
$embed = '<iframe width="560" height="315" src="https://www.youtube.com/embed/l0Qg9BmEnbs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>'; 

//$embed = '<iframe width=\'560\' height=\'315\' src=\'https://www.youtube.com/embed/l0Qg9BmEnbs\' frameborder=\'0\' allow=\'autoplay; encrypted-media\' allowfullscreen></iframe>';

$iframeVideo = $embed;

 
?>
<section id="videos" class="Section Section--style2 Section--videos u-positionRelative">
	<header class="Section-header u-marginBottom--inter u-sizeFull u-displayFlex u-flexAlignItemsCenter u-paddingVertical u-absoluteTopCenter u-paddingTop--inter--half u-zIndex5">
		<h2 class="Section-header-title Section-header-title--beforeTitleLine u-alignCenter u-marginTop u-paddingBottom--inter--half u-sizeFull"><strong>VÍDEOS</strong></h2>
	</header>
	<div class="Owl-container">
		<div id="videos-carousel" class="Section-items owl-carousel">
			
			<!-- .Section-items-item -->
			<div class="Section-items-item Section-mainContent u-displayFlex"  data-hash="1">
					<div class="Section-items-item-container u-displayFlex u-sizeFull">
						
						<div class="Section-items-item-header u-absoluteCenterMiddle u-paddingTop  u-alignCenter u-sizeFull u-zIndex2">
							<h3 class="Section-items-item-title u-displayFlex u-sizeFull u-flexDirectionRow u-flexJustifyContentSpaceBetween">
								<span class="Section-items-item-title--left u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexEnd u-alignRight u-onlyDesktop">
									Título do vídeo
								</span>
								<span class="ButtonCommand u-absoluteCenter u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentCenter u-zIndex2 ">
									<a href="javascript:LightboxCall(<?php  echo esc_html( '\'' . $iframeVideo . '\'' ); ?>);" class="u-displayInlineBlock u-positionRelative">
										<i class="IconPlay u-positionRelative u-displayBlock is-animating">
											<svg class="iconPlay u-icon u-displayBlock u-absoluteCenterMiddle is-animating">
												<use xlink:href="#iconPlay"></use>
											</svg>
										</i>
									</a>

								</span>
								<span class="Section-items-item-title--right u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexStart u-alignLeft u-onlyDesktop">
									apenas teste
								</span>
							</h3>
						</div>

						
							<figure class="Section-items-item-figure u-sizeFull u-positionRelative u-displayBlock u-overFlowHidden">
								<img class="u-displayBlock u-positionRelative u-objectFitCover u-sizeFull" src="<?php echo get_template_directory_uri(); ?>/assets/images/Section-videos-image<?php echo switch_img_Mobile(); ?>.png" alt="Title" />
							</figure>
					

					</div>
			</div>
			<!-- .Section-items-item -->
			<!-- .Section-items-item -->
			<div class="Section-items-item Section-mainContent u-displayFlex" data-hash="2">
					<div class="Section-items-item-container u-displayFlex u-sizeFull">
						
						<div class="Section-items-item-header u-absoluteCenterMiddle u-alignCenter u-sizeFull u-zIndex2">
							<h3 class="Section-items-item-title u-displayFlex u-sizeFull u-flexDirectionRow u-flexJustifyContentSpaceBetween">
								<span class="Section-items-item-title--left u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexEnd u-alignRight u-onlyDesktop">
									Título do vídeo
								</span>
								<span class="ButtonCommand u-absoluteCenter u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentCenter u-zIndex2 ">
									<a href="javascript:LightboxCall(<?php  echo esc_html( '\'' . $iframeVideo . '\'' ); ?>);" class="u-displayInlineBlock u-positionRelative">
										<i class="IconPlay u-positionRelative u-displayBlock is-animating">
											<svg class="iconPlay u-icon u-displayBlock u-absoluteCenterMiddle is-animating">
												<use xlink:href="#iconPlay"></use>
											</svg>
										</i>
									</a>

								</span>
								<span class="Section-items-item-title--right u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexStart u-alignLeft u-onlyDesktop">
									apenas teste
								</span>
							</h3>
						</div>

						
							<figure class="Section-items-item-figure u-sizeFull u-positionRelative u-displayBlock u-overFlowHidden">
								<img class="u-displayBlock u-positionRelative u-objectFitCover u-sizeFull" src="<?php echo get_template_directory_uri(); ?>/assets/images/Section-videos-image<?php echo switch_img_Mobile(); ?>.png" alt="Title" />
							</figure>
					

					</div>
			</div>
			<!-- .Section-items-item -->
			<!-- .Section-items-item -->
			<div class="Section-items-item Section-mainContent u-displayFlex" data-hash="3">
					<div class="Section-items-item-container u-displayFlex u-sizeFull">
						
						<div class="Section-items-item-header u-absoluteCenterMiddle u-alignCenter u-sizeFull u-zIndex2">
							<h3 class="Section-items-item-title u-displayFlex u-sizeFull u-flexDirectionRow u-flexJustifyContentSpaceBetween">
								<span class="Section-items-item-title--left u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexEnd u-alignRight u-onlyDesktop">
									Título do vídeo
								</span>
								<span class="ButtonCommand u-absoluteCenter u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentCenter u-zIndex2 ">
									<a href="javascript:LightboxCall(<?php  echo esc_html( '\'' . $iframeVideo . '\'' ); ?>);" class="u-displayInlineBlock u-positionRelative">
										<i class="IconPlay u-positionRelative u-displayBlock is-animating">
											<svg class="iconPlay u-icon u-displayBlock u-absoluteCenterMiddle is-animating">
												<use xlink:href="#iconPlay"></use>
											</svg>
										</i>
									</a>

								</span>
								<span class="Section-items-item-title--right u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexStart u-alignLeft u-onlyDesktop">
									apenas teste
								</span>
							</h3>
						</div>

						
							<figure class="Section-items-item-figure u-sizeFull u-positionRelative u-displayBlock u-overFlowHidden">
								<img class="u-displayBlock u-positionRelative u-objectFitCover u-sizeFull" src="<?php echo get_template_directory_uri(); ?>/assets/images/Section-videos-image<?php echo switch_img_Mobile(); ?>.png" alt="Title" />
							</figure>
					

					</div>
			</div>
			<!-- .Section-items-item -->
			<!-- .Section-items-item -->
			<div class="Section-items-item Section-mainContent u-displayFlex" data-hash="4">
					<div class="Section-items-item-container u-displayFlex u-sizeFull">
						
						<div class="Section-items-item-header u-absoluteCenterMiddle u-alignCenter u-sizeFull u-zIndex2">
							<h3 class="Section-items-item-title u-displayFlex u-sizeFull u-flexDirectionRow u-flexJustifyContentSpaceBetween">
								<span class="Section-items-item-title--left u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexEnd u-alignRight u-onlyDesktop">
									Título do vídeo
								</span>
								<span class="ButtonCommand u-absoluteCenter u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentCenter u-zIndex2 ">
									<a href="javascript:LightboxCall(<?php  echo esc_html( '\'' . $iframeVideo . '\'' ); ?>);" class="u-displayInlineBlock u-positionRelative">
										<i class="IconPlay u-positionRelative u-displayBlock is-animating">
											<svg class="iconPlay u-icon u-displayBlock u-absoluteCenterMiddle is-animating">
												<use xlink:href="#iconPlay"></use>
											</svg>
										</i>
									</a>

								</span>
								<span class="Section-items-item-title--right u-flex1 u-displayFlex u-flexAlignItemsCenter u-flexJustifyContentFlexStart u-alignLeft u-onlyDesktop">
									apenas teste
								</span>
							</h3>
						</div>

						
							<figure class="Section-items-item-figure u-sizeFull u-positionRelative u-displayBlock u-overFlowHidden">
								<img class="u-displayBlock u-positionRelative u-objectFitCover u-sizeFull" src="<?php echo get_template_directory_uri(); ?>/assets/images/Section-videos-image<?php echo switch_img_Mobile(); ?>.png" alt="Title" />
							</figure>
					

					</div>
			</div>
			<!-- .Section-items-item -->
			
		</div>
	</div>

	<nav class="Section-navigation">
	
		<ul id="videos-carousel--control" class="Section-navigation-items Section-navigation-items--tabs u-displayFlex u-maxSize--container u-alignCenterBox owl-theme owl-carousel">
			<li id="1--ControllLink" class="Section-navigation-items-item u-sizeFull Item active" data-hash="1">
				<div class="Section-navigation-items-item-container Border Border--right Border--left u-paddingHorizontal--vrt--inter--px u-marginVertical">
					<a class="NavigationLink u-displayFlex u-flexDirectionColumn u-flexJustifyContentCenter is-animating u-boxShadow--active url" href="#1">
						<div class="Section-navigation-items-item-header u-displayFlex u-flexJustifyContentSpaceBetween u-sizeFull">
							<figure class="FigureIcon FigureIcon--video u-displayBlock"></figure>
							<h4 class="Section-navigation-items-item-title u-flex1 u-marginLeft--inter--half--px u-displayFlex u-flexAlignItemsCenter">Título exemplo do vídeo</h4>
						</div>
						<p class="Section-navigation-items-item-resume u-marginTop--inter--half">Lorem ipsum é apenas mais um teste de texto</p>
					</a>
				</div>
			</li>
			<li id="2--ControllLink" class="Section-navigation-items-item u-sizeFull BorderItem" data-hash="2">
				<div class="Section-navigation-items-item-container Border Border--right u-paddingHorizontal--inter u-marginVertical">
					<a class="NavigationLink u-displayFlex u-flexDirectionColumn u-flexJustifyContentCenter is-animating u-boxShadow--active url" href="#2">
						<div class="Section-navigation-items-item-header u-displayFlex u-flexJustifyContentSpaceBetween u-sizeFull">
							<figure class="FigureIcon FigureIcon--video u-displayBlock"></figure>
							<h4 class="Section-navigation-items-item-title u-flex1 u-marginLeft--inter--half--px u-displayFlex u-flexAlignItemsCenter">Título exemplo do vídeo</h4>
						</div>
						<p class="Section-navigation-items-item-resume u-marginTop--inter--half">Lorem ipsum é apenas mais um teste de texto</p>
					</a>
				</div>
			</li>
			<li id="3--ControllLink" class="Section-navigation-items-item u-sizeFullItem" data-hash="3">
				<div class="Section-navigation-items-item-container Border Border--right u-paddingHorizontal--inter u-marginVertical">
					<a class="NavigationLink u-displayFlex u-flexDirectionColumn u-flexJustifyContentCenter is-animating u-boxShadow--active url" href="#3">
						<div class="Section-navigation-items-item-header u-displayFlex u-flexJustifyContentSpaceBetween u-sizeFull">
							<figure class="FigureIcon FigureIcon--video u-displayBlock"></figure>
							<h4 class="Section-navigation-items-item-title u-flex1 u-marginLeft--inter--half--px u-displayFlex u-flexAlignItemsCenter">Título exemplo do vídeo</h4>
						</div>
						<p class="Section-navigation-items-item-resume u-marginTop--inter--half">Lorem ipsum é apenas mais um teste de texto</p>
					</a>
				</div>
			</li>
			<li id="4--ControllLink" class="Section-navigation-items-item u-sizeFull Item" data-hash="4">
				<div class="Section-navigation-items-item-container Border Border--right u-paddingHorizontal--inter u-marginVertical">
					<a class="NavigationLink u-displayFlex u-flexDirectionColumn u-flexJustifyContentCenter is-animating u-boxShadow--active url" href="#4">
						<div class="Section-navigation-items-item-header u-displayFlex u-flexJustifyContentSpaceBetween u-sizeFull">
							<figure class="FigureIcon FigureIcon--video u-displayBlock"></figure>
							<h4 class="Section-navigation-items-item-title u-flex1 u-marginLeft--inter--half--px u-displayFlex u-flexAlignItemsCenter">Título exemplo do vídeo</h4>
						</div>
						<p class="Section-navigation-items-item-resume u-marginTop--inter--half">Lorem ipsum é apenas mais um teste de texto</p>
					</a>
				</div>
			</li>
			
		</ul>

	</nav>

</section>