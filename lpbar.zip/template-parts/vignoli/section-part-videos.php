
<div class="Section-items-item-content">
	<h4 class="Section-items-item-title u-marginBottom--inter">
		Detalhes que fazem a diferença e proporcionam uma experiência gastronômica inesquecível.
	</h4>
	<div class="Section-items-item-gallery Gallery Gallery--videos">
		<ul class="Gallery-items u-displayFlex u-flexWrapWrap u-flexAlignItemsCenter">
			<li class="Gallery-items-item u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item  u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item  u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item  u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item  u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item  u-size6of24">
				<h2>video</h2>
			</li>
			<li class="Gallery-items-item  u-size6of24">
				<h2>video</h2>
			</li>
		</ul>
	</div>
	
</div>