<section id="onde-estamos" class="Section Section--style1 Section--locais u-positionRelative">
	<div class="Section-mainContent">
		<div class="u-maxSize--container_ u-alignCenterBox_ u-alignCenter u-displayFlex u-flexDirectionColumn u-flexSwitchRow u-positionRelative"><!-- Max Size Container -->
			<div class="Section--texts u-displayFlex u-flexDirectionColumn u-size10of24 u-paddingTop u-marginTop--inter--half">
				<header class="Section-header u-marginBottom--inter u-size16of24 u-alignCenterBox u-displayFlex u-flexDirectionColumn u-flexAlignItemsCenter">
					<figure class="ArabescoTop--color_15 u-displayBlock"></figure>
					<h2 class="Section-header-title Section-header-title--beforeTitleLine u-alignCenter u-paddingHorizontal--inter--half u-sizeFull">CONHEÇA OS <strong>ESTADOS</strong> ONDE A <strong>VIGNOLI</strong> ESTÁ</h2>
				</header>
				<div class="Section-content u-alignJustify u-paddingVertical--px u-marginBottom--inter">
					<h3 class="Section-header-subtitle u-alignCenter">Estamos em três estados e expandindo para outros três. Seja você o próximo a crescer com a Vignoli!</h3>
				</div>
			</div>
			<div class="Section-imageMain u-size14of24 u-positionRelative">
					<figure class="Section-items-figure u-displayFlex u-flexJustifyContentCenter">
						<img class="u-objectFitCover u-sizeHeight100 u-sizeFull u-displayFlex u-justifyContentCenter u-flexAlignItemsCenter" src="<?php echo get_template_directory_uri() . '/assets/images/brazil-pizza--right' . switch_img_Mobile() . '.png'; ?>" />
					</figure>
			</div>
		</div>
	</div>

</section>