
<section class="Section Section--style1 u-displayFlex u-flexJustifyContentCenter u-paddingHorizontal--inter">

<!-- 	<div class="Section-container u-displayFlex u-sizeFull u-positionRelative">
		<?php// get_template_part('template-parts/page/socialmedia','bar'); ?>
	</div>

	<div class="Section-container u-displayFlex u-flexJustifyContentCenter u-sizeFull u-positionRelative u-marginBottom">
		<?php//  get_template_part('template-parts/header/header','branding');?>
	</div>

 -->
	<div class="u-maxSize--container u-alignCenterBox u-displayFlex u-flexDirectionColumn u-flexSwitchRow u-sizeFull u-flexAlignItemsCenter u-flexJustifyContentCenter">
		<div class="Section-subSection Section-subSection--bio u-size8of24">
			<p class="u-alignCenter">
				© <a href="http://www.pizzavignoli.com.br">Barney's Burger</a> <?php echo get_the_date('Y') ?>, Todos os direitos Resevados.
			</p>
		</div>
		
	</div> <!-- Max Size Container -->
</section>

<div class="u-displayBlock u-alignCenter u-paddingHorizontal--inter--half u-lineHeight0 color_5 u-sizeFull">
	<a class="u-displayInlineBlock u-lineHeight0" href="https://www.i9me.com.br/?utm_source=siteCliente&utm_medium=logoI9ME&utm_campaign=vignoli_franquia" target="_blank">
		<img src="<?php echo get_template_directory_uri(); ?>/assets/images/logptipo-i9me-web-design-fortaleza-ce.png" width="30" height="30" alt="I9ME Web & Design" />
	</a>
</div>